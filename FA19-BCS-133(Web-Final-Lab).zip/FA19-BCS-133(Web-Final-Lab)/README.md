####   Question No. 1 #####

1) Used the useState() to handle the states of username, password, error, and token
2) Created a handleForm() function to check form validation and fetching API through POST method. Showed the response in JSON. If response was successful then stored the token in local storage, otherwise showed error.

####   Question No. 2  #####
1) Created in react. Designed basic layout and just applied basic CRUD operations.