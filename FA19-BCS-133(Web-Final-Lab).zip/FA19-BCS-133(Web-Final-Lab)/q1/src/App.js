import React from 'react';
import LoginForm from './login';

function App() {
  return (
    <div>
      <LoginForm />
    </div>
  );
}

export default App;
