import React, { useState } from 'react';
import './login.css';

const LoginForm = () => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [token, setToken] = useState('');
  const [error, setError] = useState('');
  
  const handleForm = (e) => {
    e.preventDefault();
    if (!username || !password) {
        setError("Both username and password are required.");
        return;
    }
    fetch("https://dummyjson.com/auth/login", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify({ username: 'kminchelle',
        password: '0lelplR', }),
       
    })
    .then(response => response.json())
        .then(data => {
            if (data.success) {
                setToken(data.token);
                localStorage.setItem("token", data.token);
            } else {
                setError("Login failed. Please try again.");
            }
        })
        
       
};

  return (
    <form  className='lform' onSubmit={handleForm}>
        <div>
            <h1 className='heading'>Login Form</h1>
        </div>
      <div className='user'>
        <label>Username:</label>
        <input
          type="text" id="username"
          placeholder='Please Enter Your Username'
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
      </div>
      <div className='pass'>
        <label>Password:</label>
        <input
          type="password" id="password"
          placeholder='Please Enter Your Password'
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
      </div>
      <div className='btn-div'>
        <button type="submit" className='submit-btn'>Submit</button>
      </div>
      {error && <div className='err-div'>{error}</div>}
      {token && <div className='token-div'>Token: {token}</div>}
    </form>
  );
};

export default LoginForm;
