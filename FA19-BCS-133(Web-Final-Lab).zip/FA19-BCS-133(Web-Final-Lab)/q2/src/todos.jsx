import React from 'react';
import './todos.css'
import { ReactDOM } from 'react';

function Todo() {
  return (
    <div>
      <h1 className='to-head'>Todo App</h1>

      <div className='to-box'>
          <div>
            <ul className='to-list'>
                <li>Task No.</li>
                <li>Heading</li>
                <li>Description</li>
                <li> <button className='complete-btn'>Status</button></li>
                <li> <button className='complete-btn'>Actions</button></li>
             </ul>

        
          </div>

         
        
      </div>

      <div className='lists-div'>
             <ul className='to-list-2'>
                <li>Task No. 1</li>
                <li>Web Task</li>
                <li>Create MERN App</li>
                <li> <button className='complete-btn'>Completed</button></li>

                <li> <button className='complete-btn'>Edit</button>&nbsp;&nbsp;<button className='complete-btn'>Delete</button></li>
             </ul>
             <hr></hr>

             <div className='insertBtn'>
             <button className='complete-btn'>Insert</button>
             </div>
      </div>

    </div>
  );
}

export default Todo;
