import React from 'react';
import './todos.css'

function Todo() {
  return (
    <div>
         <h1> Insert</h1>
    </div>
   
  );
}

export default Todo;
