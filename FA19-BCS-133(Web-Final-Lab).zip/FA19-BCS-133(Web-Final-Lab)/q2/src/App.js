import React from 'react';
 import Todo from './todos';

 import { ReactDOM } from 'react';
function App() {

  <Router>
  return (
    <div>
      <Todo />
    </div>
  );
  </Router>
}

export default App;
